import requests
import json
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler
import os
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

#Reads the key-value pairs from a .env
load_dotenv()

# Define your Slack and PagerDuty API keys 
PAGERDUTY_API_KEY = os.environ["PAGERDUTY_API_KEY"]
SLACK_BOT_TOKEN = os.environ["SLACK_BOT_TOKEN"]
SLACK_APP_TOKEN = os.environ["SLACK_APP_TOKEN"]
PAGERDUTY_SERVICE = os.environ["PAGERDUTY_SERVICE"]


# Define the Slack channel and message
SLACK_MESSAGE = "Thanks for your message, we will look into - NOC Team"

# Define the PagerDuty service and incident
#PAGERDUTY_SERVICE = "PS0ZWUL"


#Configuration for Bot to work
app = App(token=SLACK_BOT_TOKEN)
client = WebClient(token=SLACK_BOT_TOKEN)


#Adding Slack API to trigger whenever the slack bot is called
@app.event("app_mention")                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
def mention_handler(body, say):
        # Make a request to PagerDuty to get the on-call user
        headers = { 
            "Accept": "application/vnd.pagerduty+json;version=2",
            "Authorization": f"Token token={PAGERDUTY_API_KEY}"
            }

        params = {  
            "include[]": "users",
            "time_zone": "UTC"
            }

        response = requests.get(
            f"https://api.pagerduty.com/oncalls?include[]=users&schedule_ids[]={PAGERDUTY_SERVICE}&earliest=true",
            headers=headers,
            params=params
            )
        data = json.loads(response.text)


        # Get the user name of the on-call user  -- #Alternative you can use user Id as well
        name = data.get('oncalls')
        get_user_tag = name[0].get('user')
        email_tag_untrimmed = get_user_tag.get('email' )
        on_call_user_tag = email_tag_untrimmed[:-12]
        print(on_call_user_tag)

        #tag the user in the response message
        bot_response = client.auth_test()
        username_find = bot_response["user"]
        slack_message_with_tag = f"<@{on_call_user_tag}"
        response_message = f"{slack_message_with_tag}> {SLACK_MESSAGE}"
        say(response_message)

        # Send the response message
        #app.client.chat_postMessage(channel=body["channel"], text=response_message)


        if response.status_code == 200:
            print("Message sent successfully!")
        else:
            print("Error sending message.")


if __name__ == "__main__":
        handler = SocketModeHandler(app, SLACK_APP_TOKEN)
        handler.start()
